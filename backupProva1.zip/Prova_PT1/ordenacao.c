#include <stdio.h>
#include <stdlib.h>
#include "listaDuplamenteEncadeada.h"
#include "tratamentoArquivos.h"
#include "aluno.h"
#include <string.h>
#include "ordenacao.h"

void exibirMenuOrdenacao(TLLDE * const lista, char nomeArquivo[]){
    do{
        int opcao = -1;
        int posicao = -1;
        int direcao = -1;

        printf("\n================== MENU DE ORDENACAO ==================\n");
        printf("1. Ordenar pela Matricula\n");
        printf("2. Ordenar pelo Nome\n");
        printf("3. Ordenar pelo Curso e Nome\n");
        printf("4. Ordenar pela Enfase e Nome\n");
        printf("5. Mostrar lista\n\n");
        printf("6. Voltar\n");
        printf("0. Encerrar o Programa\n\n");
        printf("Opcao: ");
        scanf("%d", &opcao);
        getchar();

        switch(opcao){
            case 1:

            break;

            case 2:

            break;

            case 3:
            
            break;

            case 4:
            
            break;

            case 5:
            direcao = -1;
            printf("\nDirecao desejada\n1. Inicio->Fim\n0. Fim->Inicio\n");
            printf("Opcao: ");
            scanf("%d", &direcao);
            getchar();
            if(direcao){
                mostrarLista(lista, 1);
            }
            else{
                mostrarLista(lista, 0);
            }
            break;

            case 6:
            printf("Voltando..\n");
            return;

            case 0:
            salvarListaNoArquivo(lista, nomeArquivo); 
            liberarLista(lista);
            printf("\nEncerrando...\n");
            exit(0);


            default:
            printf("\nOpcao invalida!\n");

        }
    }while(1);
}