#ifndef ORDENACAO_H
#define ORDENACAO_H

#include "listaDuplamenteEncadeada.h"

void exibirMenuOrdenacao(TLLDE * const lista, char nomeArquivo[]);

#endif